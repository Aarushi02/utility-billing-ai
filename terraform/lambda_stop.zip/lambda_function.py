import boto3, os

def handler(event, context):
    ec2 = boto3.client("ec2", region_name=os.environ["AWS_REGION_NAME"])
    instance_id = os.environ["INSTANCE_ID"]
    ec2.stop_instances(InstanceIds=[instance_id])
    print(f"Stopped EC2 instance: {instance_id}")
    return {"status": "stopped", "instance_id": instance_id}
