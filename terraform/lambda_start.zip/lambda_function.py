import boto3, os

def handler(event, context):
    ec2 = boto3.client("ec2", region_name=os.environ["AWS_REGION_NAME"])
    instance_id = os.environ["INSTANCE_ID"]
    ec2.start_instances(InstanceIds=[instance_id])
    print(f"Started EC2 instance: {instance_id}")
    return {"status": "started", "instance_id": instance_id}
